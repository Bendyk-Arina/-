class TELEPHONE:
    # Конструктор класу
    def __init__(self, my_number, model):
        self.my_number = my_number      # Номер вашого телефону
        self.model = model              # Модель телефону
        self.incoming_calls = []        # Порожній список для вхідних дзвінків

    # Метод для прийому дзвінка
    def Call(self, caller_name, caller_number):
        self.incoming_calls.append(caller_number)   # Додавання номер у кінець списку вхідних дзвінків
        print(f"Вам телефонує {caller_name} з номера {caller_number}.")

    # Метод для видалення останнього дзвінка
    def DeleteCall(self):
        if len(self.incoming_calls) > 0:    # Перевірка, чи список не порожній
            deleted_number = self.incoming_calls.pop()  # .pop() видаляє останній елемент
            print(f"Останній номер ({deleted_number}) видалено зі списку.")
        else:
            print("Список вхідних дзвінків уже порожній.")
