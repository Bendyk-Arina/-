from phone_module import TELEPHONE

# Створення об'єкту телефону
my_phone = TELEPHONE("+380501112233", "iPhone 15")
print(f"Модель: {my_phone.model}, Мій номер: {my_phone.my_number}\n")

# Вхідні дзвінки
my_phone.Call("Мама", "+380679998877")
my_phone.Call("Тато", "+380935554433")

print("Список вхідних дзвінків:", my_phone.incoming_calls, "\n")

# Видалення останнього вхідного дзвінка
my_phone.DeleteCall()

print("Оновлений список дзвінків:", my_phone.incoming_calls)
