import math
def radius_opysanoho(a):
    R = (a * math.sqrt(2)) / 2  
    return R
def radius_vpysanoho(a):
    r = a / 2
    return r 