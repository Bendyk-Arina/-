import mymodule

a = float(input("Введіть сторону квадрата a: "))

# Викликаємо функції з модуля
R = mymodule.radius_opysanoho(a)
r = mymodule.radius_vpysanoho(a)

# округлюємо до 2 знаків після коми
print("Радіус описаного кола R =", round(R, 2))
print("Радіус вписаного кола r =", round(r, 2))